public interface Vendavel {
    public double getValorTotal();
}
