public interface IVendavel {
    public Double getValorImposto();
}
