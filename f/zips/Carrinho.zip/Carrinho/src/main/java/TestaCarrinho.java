import java.util.Scanner;

public class TestaCarrinho {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

        Carrinho carrinho = new Carrinho();


        while(true) {
        System.out.println("Menu Do vendedor");
        System.out.println("1 - Adicionar Livro" +
                "\n2 - Adicionar DVD" +
                "\n3 - Adicionar Servico" +
                "\n4 - Exibir itens do carrinho" +
                "\n5 - Exibir Total de Vendas" +
                "\n6 - Fim");

            System.out.println("Digite um número:");
             Integer opcoes = ler.nextInt();

            switch (opcoes) {

                case 1:
                    System.out.println("codigo livro: ");
                    var codigoLivro = ler.nextInt();

                    System.out.println("nome: ");
                    var nomeLivro = ler.nextLine();

                    System.out.print("preco: ");
                    var precoLivro = ler.nextDouble();

                    System.out.print("autor: ");
                    var autor = ler.nextLine();

                    System.out.print("isbn: ");
                    var isbn = ler.nextLine();

                    Livro livro = new Livro(codigoLivro,nomeLivro,precoLivro,autor,isbn);
                    carrinho.adicionarVenda(livro);
                    opcoes = 0;
                    break;

                case 2 :
                    System.out.print("codigo DVD: ");
                    var codigoDvd = ler.nextInt();

                    System.out.print("nome: ");
                    var nomeDvd = ler.nextLine();

                    System.out.print("preco: ");
                    var precoDvd = ler.nextDouble();

                    System.out.print("gravadora: ");
                    var gravadora = ler.nextLine();

                    DVD dvd = new DVD(codigoDvd,nomeDvd,precoDvd,gravadora);
                    carrinho.adicionarVenda(dvd);
                    opcoes = 0;
                    break;

                case 3 :
                    System.out.print("descricao: ");
                    var descricao = ler.nextLine();

                    System.out.print("codigo: ");
                    var codigo = ler.nextInt();

                    System.out.print("qtd Horas: ");
                    var qtdHoras = ler.nextInt();

                    System.out.print("valor Horas: ");
                    var valorHora = ler.nextDouble();

                    Servico servico = new Servico(descricao,codigo,qtdHoras,valorHora);
                    carrinho.adicionarVenda(servico);
                    opcoes = 0;

                    break;

                case 4 :
                    carrinho.exibItensCarrinho();
                    opcoes = 0;

                    break;

                case 5 :
                    carrinho.calcularTotaVenda();
                    opcoes = 0;

                    break;

                default :
                    opcoes = 6;
                    break;
            }

        }
    }
}
