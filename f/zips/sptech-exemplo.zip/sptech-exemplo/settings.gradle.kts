rootProject.name = "sptech-exemplo"
