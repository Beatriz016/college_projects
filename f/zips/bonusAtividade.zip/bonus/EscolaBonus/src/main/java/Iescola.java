public interface Iescola {
    public double getValorBonus();
}
