package sptech.example.c102211004beatrizvitoriacardoso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C102211004BeatrizVitoriaCardosoApplicationTests {

	@Test
	void contextLoads() {
	}

}
