package sptech.example.c102211004beatrizvitoriacardoso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C102211004BeatrizVitoriaCardosoApplication {

	public static void main(String[] args) {
		SpringApplication.run(C102211004BeatrizVitoriaCardosoApplication.class, args);
	}

}
